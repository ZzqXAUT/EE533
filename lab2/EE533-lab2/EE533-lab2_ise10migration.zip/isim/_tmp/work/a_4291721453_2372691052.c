/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Documents and Settings/student/EE533-lab2/statmach.vhd";



static void work_a_4291721453_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;

LAB0:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 2132U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 548U);
    t2 = *((char **)t1);
    t4 = *((unsigned char *)t2);
    t10 = (t4 == (unsigned char)3);
    if (t10 == 1)
        goto LAB7;

LAB8:    t3 = (unsigned char)0;

LAB9:    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 4328);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2296U);
    t5 = *((char **)t1);
    t1 = (t0 + 4396);
    t6 = (t1 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(49, ng0);
    t1 = (t0 + 4432);
    t2 = (t1 + 32U);
    t5 = *((char **)t2);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 4468);
    t2 = (t1 + 32U);
    t5 = *((char **)t2);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB5:    xsi_set_current_line(52, ng0);
    t5 = (t0 + 1604U);
    t6 = *((char **)t5);
    t5 = (t0 + 4396);
    t7 = (t5 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    memcpy(t12, t6, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 1868U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4432);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 2044U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4468);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 40U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB3;

LAB7:    t1 = (t0 + 528U);
    t11 = xsi_signal_has_event(t1);
    t3 = t11;
    goto LAB9;

}

static void work_a_4291721453_2372691052_p_1(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 548U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 4336);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(61, ng0);
    t7 = (t0 + 1780U);
    t8 = *((char **)t7);
    t7 = (t0 + 4504);
    t9 = (t7 + 32U);
    t10 = *((char **)t9);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t8, 2U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 1956U);
    t3 = *((char **)t2);
    t1 = *((unsigned char *)t3);
    t2 = (t0 + 4540);
    t7 = (t2 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t1;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB3;

LAB5:    t2 = (t0 + 528U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

}

static void work_a_4291721453_2372691052_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    int t9;
    int t10;
    char *t11;
    int t12;
    char *t13;
    int t14;
    char *t15;
    int t16;
    char *t17;
    int t18;
    char *t19;
    int t20;
    char *t21;
    int t22;
    char *t23;
    int t24;
    char *t25;
    int t26;
    char *t27;
    int t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    unsigned char t34;
    unsigned char t35;
    unsigned char t36;
    unsigned char t37;
    unsigned char t38;
    unsigned char t39;
    unsigned char t40;
    unsigned char t41;
    unsigned char t42;
    unsigned char t43;
    unsigned char t44;
    unsigned char t45;
    unsigned char t46;
    unsigned char t47;
    unsigned char t48;
    unsigned char t49;
    unsigned char t50;

LAB0:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(71, ng0);
    t1 = (t0 + 2296U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 3128U);
    t2 = *((char **)t1);
    t1 = (t0 + 4792);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1516U);
    t2 = *((char **)t1);
    t1 = (t0 + 2296U);
    t3 = *((char **)t1);
    t7 = xsi_mem_cmp(t3, t2, 4U);
    if (t7 == 1)
        goto LAB3;

LAB17:    t1 = (t0 + 2360U);
    t4 = *((char **)t1);
    t8 = xsi_mem_cmp(t4, t2, 4U);
    if (t8 == 1)
        goto LAB4;

LAB18:    t1 = (t0 + 2424U);
    t5 = *((char **)t1);
    t9 = xsi_mem_cmp(t5, t2, 4U);
    if (t9 == 1)
        goto LAB5;

LAB19:    t1 = (t0 + 2488U);
    t6 = *((char **)t1);
    t10 = xsi_mem_cmp(t6, t2, 4U);
    if (t10 == 1)
        goto LAB6;

LAB20:    t1 = (t0 + 2552U);
    t11 = *((char **)t1);
    t12 = xsi_mem_cmp(t11, t2, 4U);
    if (t12 == 1)
        goto LAB7;

LAB21:    t1 = (t0 + 2616U);
    t13 = *((char **)t1);
    t14 = xsi_mem_cmp(t13, t2, 4U);
    if (t14 == 1)
        goto LAB8;

LAB22:    t1 = (t0 + 2680U);
    t15 = *((char **)t1);
    t16 = xsi_mem_cmp(t15, t2, 4U);
    if (t16 == 1)
        goto LAB9;

LAB23:    t1 = (t0 + 2744U);
    t17 = *((char **)t1);
    t18 = xsi_mem_cmp(t17, t2, 4U);
    if (t18 == 1)
        goto LAB10;

LAB24:    t1 = (t0 + 2808U);
    t19 = *((char **)t1);
    t20 = xsi_mem_cmp(t19, t2, 4U);
    if (t20 == 1)
        goto LAB11;

LAB25:    t1 = (t0 + 2872U);
    t21 = *((char **)t1);
    t22 = xsi_mem_cmp(t21, t2, 4U);
    if (t22 == 1)
        goto LAB12;

LAB26:    t1 = (t0 + 2936U);
    t23 = *((char **)t1);
    t24 = xsi_mem_cmp(t23, t2, 4U);
    if (t24 == 1)
        goto LAB13;

LAB27:    t1 = (t0 + 3000U);
    t25 = *((char **)t1);
    t26 = xsi_mem_cmp(t25, t2, 4U);
    if (t26 == 1)
        goto LAB14;

LAB28:    t1 = (t0 + 3064U);
    t27 = *((char **)t1);
    t28 = xsi_mem_cmp(t27, t2, 4U);
    if (t28 == 1)
        goto LAB15;

LAB29:
LAB16:
LAB2:    xsi_set_current_line(265, ng0);
    t1 = (t0 + 2132U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB136;

LAB138:    xsi_set_current_line(269, ng0);
    t1 = (t0 + 1692U);
    t2 = *((char **)t1);
    t1 = (t0 + 3128U);
    t3 = *((char **)t1);
    t7 = xsi_mem_cmp(t3, t2, 2U);
    if (t7 == 1)
        goto LAB140;

LAB144:    t1 = (t0 + 3192U);
    t4 = *((char **)t1);
    t8 = xsi_mem_cmp(t4, t2, 2U);
    if (t8 == 1)
        goto LAB141;

LAB145:    t1 = (t0 + 3256U);
    t5 = *((char **)t1);
    t9 = xsi_mem_cmp(t5, t2, 2U);
    if (t9 == 1)
        goto LAB142;

LAB146:
LAB143:
LAB139:
LAB137:    t1 = (t0 + 4344);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4684);
    t29 = (t1 + 32U);
    t30 = *((char **)t29);
    t31 = (t30 + 40U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(78, ng0);
    if ((unsigned char)1 != 0)
        goto LAB31;

LAB33:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2296U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(85, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB32:    goto LAB2;

LAB4:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(89, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(90, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t34 = *((unsigned char *)t2);
    t35 = (t34 == (unsigned char)3);
    if (t35 == 1)
        goto LAB37;

LAB38:    t1 = (t0 + 812U);
    t3 = *((char **)t1);
    t37 = *((unsigned char *)t3);
    t38 = (t37 == (unsigned char)3);
    if (t38 == 1)
        goto LAB40;

LAB41:    t36 = (unsigned char)0;

LAB42:    t33 = t36;

LAB39:    t41 = (!(t33));
    if (t41 != 0)
        goto LAB34;

LAB36:
LAB35:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB43;

LAB45:
LAB44:    xsi_set_current_line(101, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t34 = *((unsigned char *)t2);
    t35 = (t34 == (unsigned char)3);
    if (t35 == 1)
        goto LAB49;

LAB50:    t33 = (unsigned char)0;

LAB51:    if (t33 != 0)
        goto LAB46;

LAB48:
LAB47:    goto LAB2;

LAB5:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(108, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(109, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t34 = *((unsigned char *)t2);
    t35 = (t34 == (unsigned char)2);
    if (t35 == 1)
        goto LAB55;

LAB56:    t1 = (t0 + 988U);
    t3 = *((char **)t1);
    t36 = *((unsigned char *)t3);
    t37 = (t36 == (unsigned char)3);
    t33 = t37;

LAB57:    t38 = (!(t33));
    if (t38 != 0)
        goto LAB52;

LAB54:
LAB53:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB58;

LAB60:
LAB59:    xsi_set_current_line(119, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB61;

LAB63:
LAB62:    goto LAB2;

LAB6:    xsi_set_current_line(125, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(126, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(127, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t34 = *((unsigned char *)t2);
    t35 = (t34 == (unsigned char)3);
    if (t35 == 1)
        goto LAB67;

LAB68:    t1 = (t0 + 988U);
    t3 = *((char **)t1);
    t36 = *((unsigned char *)t3);
    t37 = (t36 == (unsigned char)2);
    t33 = t37;

LAB69:    t38 = (!(t33));
    if (t38 != 0)
        goto LAB64;

LAB66:
LAB65:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB70;

LAB72:
LAB71:    xsi_set_current_line(137, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB73;

LAB75:
LAB74:    goto LAB2;

LAB7:    xsi_set_current_line(143, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(144, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(145, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB76;

LAB78:    xsi_set_current_line(150, ng0);
    t1 = (t0 + 2552U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(151, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(152, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB77:    goto LAB2;

LAB8:    xsi_set_current_line(155, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(156, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(157, ng0);
    if ((unsigned char)1 != 0)
        goto LAB79;

LAB81:    xsi_set_current_line(162, ng0);
    t1 = (t0 + 2616U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(163, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(164, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB80:    goto LAB2;

LAB9:    xsi_set_current_line(167, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(168, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(169, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB82;

LAB84:    xsi_set_current_line(174, ng0);
    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(175, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(176, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB83:    goto LAB2;

LAB10:    xsi_set_current_line(179, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(180, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(181, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB85;

LAB87:    xsi_set_current_line(186, ng0);
    t1 = (t0 + 2744U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(187, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(188, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB86:    goto LAB2;

LAB11:    xsi_set_current_line(191, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(192, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(193, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t36 = *((unsigned char *)t2);
    t37 = (t36 == (unsigned char)3);
    if (t37 == 1)
        goto LAB97;

LAB98:    t35 = (unsigned char)0;

LAB99:    if (t35 == 1)
        goto LAB94;

LAB95:    t1 = (t0 + 724U);
    t4 = *((char **)t1);
    t40 = *((unsigned char *)t4);
    t41 = (t40 == (unsigned char)3);
    t34 = t41;

LAB96:    if (t34 == 1)
        goto LAB91;

LAB92:    t1 = (t0 + 812U);
    t5 = *((char **)t1);
    t44 = *((unsigned char *)t5);
    t45 = (t44 == (unsigned char)3);
    if (t45 == 1)
        goto LAB103;

LAB104:    t43 = (unsigned char)0;

LAB105:    if (t43 == 1)
        goto LAB100;

LAB101:    t42 = (unsigned char)0;

LAB102:    t33 = t42;

LAB93:    t50 = (!(t33));
    if (t50 != 0)
        goto LAB88;

LAB90:
LAB89:    xsi_set_current_line(199, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t34 = *((unsigned char *)t2);
    t35 = (t34 == (unsigned char)3);
    if (t35 == 1)
        goto LAB109;

LAB110:    t33 = (unsigned char)0;

LAB111:    if (t33 != 0)
        goto LAB106;

LAB108:
LAB107:    xsi_set_current_line(204, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB112;

LAB114:
LAB113:    xsi_set_current_line(209, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t35 = *((unsigned char *)t2);
    t36 = (t35 == (unsigned char)3);
    if (t36 == 1)
        goto LAB121;

LAB122:    t34 = (unsigned char)0;

LAB123:    if (t34 == 1)
        goto LAB118;

LAB119:    t33 = (unsigned char)0;

LAB120:    if (t33 != 0)
        goto LAB115;

LAB117:
LAB116:    goto LAB2;

LAB12:    xsi_set_current_line(215, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(216, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(217, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB124;

LAB126:    xsi_set_current_line(222, ng0);
    t1 = (t0 + 2872U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(223, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(224, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB125:    goto LAB2;

LAB13:    xsi_set_current_line(227, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(228, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(229, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB127;

LAB129:    xsi_set_current_line(234, ng0);
    t1 = (t0 + 2936U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(235, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(236, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB128:    goto LAB2;

LAB14:    xsi_set_current_line(239, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(240, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(241, ng0);
    t1 = (t0 + 988U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB130;

LAB132:    xsi_set_current_line(246, ng0);
    t1 = (t0 + 3000U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(247, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(248, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB131:    goto LAB2;

LAB15:    xsi_set_current_line(251, ng0);
    t1 = (t0 + 4684);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(252, ng0);
    t1 = (t0 + 4648);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(253, ng0);
    t1 = (t0 + 812U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB133;

LAB135:    xsi_set_current_line(258, ng0);
    t1 = (t0 + 3064U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(259, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(260, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB134:    goto LAB2;

LAB30:;
LAB31:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 3064U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(80, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB32;

LAB34:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 2360U);
    t5 = *((char **)t1);
    t1 = (t0 + 4756);
    t6 = (t1 + 32U);
    t11 = *((char **)t6);
    t13 = (t11 + 40U);
    t15 = *((char **)t13);
    memcpy(t15, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(94, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB35;

LAB37:    t33 = (unsigned char)1;
    goto LAB39;

LAB40:    t1 = (t0 + 988U);
    t4 = *((char **)t1);
    t39 = *((unsigned char *)t4);
    t40 = (t39 == (unsigned char)2);
    t36 = t40;
    goto LAB42;

LAB43:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 2488U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(98, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(99, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB44;

LAB46:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 2744U);
    t4 = *((char **)t1);
    t1 = (t0 + 4756);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t11 = (t6 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t4, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(103, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(104, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB47;

LAB49:    t1 = (t0 + 988U);
    t3 = *((char **)t1);
    t36 = *((unsigned char *)t3);
    t37 = (t36 == (unsigned char)2);
    t33 = t37;
    goto LAB51;

LAB52:    xsi_set_current_line(110, ng0);
    t1 = (t0 + 2424U);
    t4 = *((char **)t1);
    t1 = (t0 + 4756);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t11 = (t6 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t4, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(111, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(112, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB53;

LAB55:    t33 = (unsigned char)1;
    goto LAB57;

LAB58:    xsi_set_current_line(115, ng0);
    t1 = (t0 + 2424U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(116, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(117, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB59;

LAB61:    xsi_set_current_line(120, ng0);
    t1 = (t0 + 2552U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(121, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(122, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB62;

LAB64:    xsi_set_current_line(128, ng0);
    t1 = (t0 + 2488U);
    t4 = *((char **)t1);
    t1 = (t0 + 4756);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t11 = (t6 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t4, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(129, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(130, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB65;

LAB67:    t33 = (unsigned char)1;
    goto LAB69;

LAB70:    xsi_set_current_line(133, ng0);
    t1 = (t0 + 2488U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(134, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(135, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB71;

LAB73:    xsi_set_current_line(138, ng0);
    t1 = (t0 + 2424U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(139, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(140, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB74;

LAB76:    xsi_set_current_line(146, ng0);
    t1 = (t0 + 2360U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(147, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(148, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB77;

LAB79:    xsi_set_current_line(158, ng0);
    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    t1 = (t0 + 4756);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(159, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(160, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB80;

LAB82:    xsi_set_current_line(170, ng0);
    t1 = (t0 + 2808U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(171, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(172, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB83;

LAB85:    xsi_set_current_line(182, ng0);
    t1 = (t0 + 2808U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(183, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(184, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB86;

LAB88:    xsi_set_current_line(195, ng0);
    t1 = (t0 + 2808U);
    t13 = *((char **)t1);
    t1 = (t0 + 4756);
    t15 = (t1 + 32U);
    t17 = *((char **)t15);
    t19 = (t17 + 40U);
    t21 = *((char **)t19);
    memcpy(t21, t13, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(196, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(197, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB89;

LAB91:    t33 = (unsigned char)1;
    goto LAB93;

LAB94:    t34 = (unsigned char)1;
    goto LAB96;

LAB97:    t1 = (t0 + 724U);
    t3 = *((char **)t1);
    t38 = *((unsigned char *)t3);
    t39 = (t38 == (unsigned char)2);
    t35 = t39;
    goto LAB99;

LAB100:    t1 = (t0 + 988U);
    t11 = *((char **)t1);
    t48 = *((unsigned char *)t11);
    t49 = (t48 == (unsigned char)2);
    t42 = t49;
    goto LAB102;

LAB103:    t1 = (t0 + 724U);
    t6 = *((char **)t1);
    t46 = *((unsigned char *)t6);
    t47 = (t46 == (unsigned char)2);
    t43 = t47;
    goto LAB105;

LAB106:    xsi_set_current_line(200, ng0);
    t1 = (t0 + 2936U);
    t4 = *((char **)t1);
    t1 = (t0 + 4756);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t11 = (t6 + 40U);
    t13 = *((char **)t11);
    memcpy(t13, t4, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(201, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(202, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB107;

LAB109:    t1 = (t0 + 724U);
    t3 = *((char **)t1);
    t36 = *((unsigned char *)t3);
    t37 = (t36 == (unsigned char)2);
    t33 = t37;
    goto LAB111;

LAB112:    xsi_set_current_line(205, ng0);
    t1 = (t0 + 2616U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(206, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(207, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB113;

LAB115:    xsi_set_current_line(210, ng0);
    t1 = (t0 + 3064U);
    t5 = *((char **)t1);
    t1 = (t0 + 4756);
    t6 = (t1 + 32U);
    t11 = *((char **)t6);
    t13 = (t11 + 40U);
    t15 = *((char **)t13);
    memcpy(t15, t5, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(211, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(212, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB116;

LAB118:    t1 = (t0 + 988U);
    t4 = *((char **)t1);
    t39 = *((unsigned char *)t4);
    t40 = (t39 == (unsigned char)2);
    t33 = t40;
    goto LAB120;

LAB121:    t1 = (t0 + 724U);
    t3 = *((char **)t1);
    t37 = *((unsigned char *)t3);
    t38 = (t37 == (unsigned char)2);
    t34 = t38;
    goto LAB123;

LAB124:    xsi_set_current_line(218, ng0);
    t1 = (t0 + 3000U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(219, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(220, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB125;

LAB127:    xsi_set_current_line(230, ng0);
    t1 = (t0 + 2872U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(231, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(232, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB128;

LAB130:    xsi_set_current_line(242, ng0);
    t1 = (t0 + 2808U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(243, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(244, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB131;

LAB133:    xsi_set_current_line(254, ng0);
    t1 = (t0 + 2360U);
    t3 = *((char **)t1);
    t1 = (t0 + 4756);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 4U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(255, ng0);
    t1 = (t0 + 4720);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(256, ng0);
    t1 = (t0 + 4576);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB134;

LAB136:    xsi_set_current_line(266, ng0);
    t1 = (t0 + 3192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4792);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(267, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB137;

LAB140:    xsi_set_current_line(271, ng0);
    t1 = (t0 + 724U);
    t6 = *((char **)t1);
    t33 = *((unsigned char *)t6);
    t34 = (t33 == (unsigned char)2);
    if (t34 != 0)
        goto LAB148;

LAB150:    xsi_set_current_line(275, ng0);
    t1 = (t0 + 3128U);
    t2 = *((char **)t1);
    t1 = (t0 + 4792);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(276, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB149:    goto LAB139;

LAB141:    xsi_set_current_line(279, ng0);
    t1 = (t0 + 724U);
    t2 = *((char **)t1);
    t33 = *((unsigned char *)t2);
    t34 = (t33 == (unsigned char)3);
    if (t34 != 0)
        goto LAB151;

LAB153:    xsi_set_current_line(283, ng0);
    t1 = (t0 + 3192U);
    t2 = *((char **)t1);
    t1 = (t0 + 4792);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(284, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB152:    goto LAB139;

LAB142:    xsi_set_current_line(287, ng0);
    if ((unsigned char)1 != 0)
        goto LAB154;

LAB156:    xsi_set_current_line(291, ng0);
    t1 = (t0 + 3256U);
    t2 = *((char **)t1);
    t1 = (t0 + 4792);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(292, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB155:    goto LAB139;

LAB147:;
LAB148:    xsi_set_current_line(272, ng0);
    t1 = (t0 + 3192U);
    t11 = *((char **)t1);
    t1 = (t0 + 4792);
    t13 = (t1 + 32U);
    t15 = *((char **)t13);
    t17 = (t15 + 40U);
    t19 = *((char **)t17);
    memcpy(t19, t11, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(273, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB149;

LAB151:    xsi_set_current_line(280, ng0);
    t1 = (t0 + 3256U);
    t3 = *((char **)t1);
    t1 = (t0 + 4792);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t11 = *((char **)t6);
    memcpy(t11, t3, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(281, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB152;

LAB154:    xsi_set_current_line(288, ng0);
    t1 = (t0 + 3128U);
    t2 = *((char **)t1);
    t1 = (t0 + 4792);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(289, ng0);
    t1 = (t0 + 4612);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB155;

}

static void work_a_4291721453_2372691052_p_3(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(301, ng0);
    t2 = (t0 + 636U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    t6 = (!(t5));
    if (t6 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(302, ng0);
    t2 = (t0 + 4828);
    t3 = (t2 + 32U);
    t7 = *((char **)t3);
    t10 = (t7 + 40U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);

LAB3:    t2 = (t0 + 4352);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(301, ng0);
    t2 = (t0 + 4828);
    t10 = (t2 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    goto LAB3;

LAB5:    t2 = (t0 + 900U);
    t7 = *((char **)t2);
    t8 = *((unsigned char *)t7);
    t9 = (t8 == (unsigned char)3);
    t1 = t9;
    goto LAB7;

}


extern void work_a_4291721453_2372691052_init()
{
	static char *pe[] = {(void *)work_a_4291721453_2372691052_p_0,(void *)work_a_4291721453_2372691052_p_1,(void *)work_a_4291721453_2372691052_p_2,(void *)work_a_4291721453_2372691052_p_3};
	xsi_register_didat("work_a_4291721453_2372691052", "isim/_tmp/work/a_4291721453_2372691052.didat");
	xsi_register_executes(pe);
}
